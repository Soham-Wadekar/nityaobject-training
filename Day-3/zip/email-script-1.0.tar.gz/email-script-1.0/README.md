# Day 2 Log

### PROBLEM STATEMENT
> Task 1: Learn the `rpm` package
> Task 2: Create a rpm package of the python code and install it in a specific directory

**METHODOLOGY**<br>
*Task 1*
1. Copy the code to a separate folder
2. Create a Docker container and run the `fedora` shell inside it
3. Installed necessary packages
4. Tested basic commands for querying, installing, updating, erasing. Also learned about writing a `.spec` file.

*Task 2*
1. 


**WHAT I LEARNED**
1. How to create a Dockerfile
2. How to build a Docker image and run a container
3. How to perform a Trivy scan

**REFERENCE MATERIAL**
https://www.youtube.com/watch?v=fqMOX6JJhGo&t=1636s
